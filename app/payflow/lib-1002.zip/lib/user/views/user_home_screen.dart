import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:payflow/common/controllers/auth_controller.dart';
import 'package:payflow/common/utils/app_colors.dart';
import 'package:payflow/common/views/create_payment_screen.dart';

class UserHomeScreen extends StatelessWidget {
  const UserHomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final authController = Get.find<AuthController>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('User Home'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => authController.logout(),
          ),
        ],
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.person_rounded, size: 240.sp, color: AppColors.primary),
            SizedBox(height: 48.h),
            Text(
              'Welcome, User!',
              style: TextStyle(
                fontSize: 72.sp,
                fontWeight: FontWeight.bold,
                color: AppColors.textPrimary,
              ),
            ),
            SizedBox(height: 24.h),
            Obx(
              () => Text(
                authController.userEmail.value ?? '',
                style: TextStyle(
                  fontSize: 36.sp,
                  color: AppColors.textSecondary,
                ),
              ),
            ),
            FloatingActionButton(
              onPressed: () => Get.to(() => const CreatePaymentScreen()),
              backgroundColor: AppColors.primary,
              child: Icon(Icons.payment_rounded, size: 64.sp),
            ),
          ],
        ),
      ),
    );
  }
}
