// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:get/get.dart';
// import 'package:payflow/common/controllers/auth_controller.dart';
// import 'package:payflow/common/utils/app_colors.dart';
// import 'package:payflow/common/utils/app_routes.dart';

// class SplashScreen extends StatefulWidget {
//   const SplashScreen({super.key});

//   @override
//   State<SplashScreen> createState() => _SplashScreenState();
// }

// class _SplashScreenState extends State<SplashScreen>
//     with SingleTickerProviderStateMixin {
//   late AnimationController _animationController;
//   late Animation<double> _fadeAnimation;
//   late Animation<double> _scaleAnimation;

//   @override
//   void initState() {
//     super.initState();
//     _setupAnimations();
//     _navigate();
//   }

//   void _setupAnimations() {
//     _animationController = AnimationController(
//       duration: const Duration(milliseconds: 1500),
//       vsync: this,
//     );

//     _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
//       CurvedAnimation(
//         parent: _animationController,
//         curve: const Interval(0.0, 0.6, curve: Curves.easeIn),
//       ),
//     );

//     _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
//       CurvedAnimation(
//         parent: _animationController,
//         curve: const Interval(0.0, 0.6, curve: Curves.easeOut),
//       ),
//     );

//     _animationController.forward();
//   }

//   Future<void> _navigate() async {
//     await Future.delayed(const Duration(seconds: 3));

//     final authController = Get.find<AuthController>();

//     if (authController.isAuthenticated.value) {
//       if (authController.isUser) {
//         Get.offAllNamed(AppRoutes.userHome);
//       } else if (authController.isMerchant) {
//         Get.offAllNamed(AppRoutes.merchantHome);
//       } else {
//         Get.offAllNamed(AppRoutes.roleSelection);
//       }
//     } else {
//       Get.offAllNamed(AppRoutes.roleSelection);
//     }
//   }

//   @override
//   void dispose() {
//     _animationController.dispose();
//     super.dispose();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: AppColors.primary,
//       body: Center(
//         child: AnimatedBuilder(
//           animation: _animationController,
//           builder: (context, child) {
//             return FadeTransition(
//               opacity: _fadeAnimation,
//               child: ScaleTransition(
//                 scale: _scaleAnimation,
//                 child: Column(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Container(
//                       padding: EdgeInsets.all(72.w),
//                       decoration: BoxDecoration(
//                         color: Colors.white.withOpacity(0.1),
//                         borderRadius: BorderRadius.circular(48.r),
//                       ),
//                       child: Icon(
//                         Icons.account_balance_wallet_rounded,
//                         size: 240.sp,
//                         color: Colors.white,
//                       ),
//                     ),
//                     SizedBox(height: 72.h),
//                     Text(
//                       'PayFlow',
//                       style: TextStyle(
//                         fontSize: 108.sp,
//                         fontWeight: FontWeight.bold,
//                         color: Colors.white,
//                         letterSpacing: 2,
//                       ),
//                     ),
//                     SizedBox(height: 32.h),
//                     Text(
//                       'Seamless Payments, Effortless Transfers',
//                       textAlign: TextAlign.center,
//                       style: TextStyle(
//                         fontSize: 36.sp,
//                         color: Colors.white.withOpacity(0.9),
//                         letterSpacing: 0.5,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//             );
//           },
//         ),
//       ),
//     );
//   }
// }

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:payflow/common/controllers/auth_controller.dart';
import 'package:payflow/common/utils/app_colors.dart';
import 'package:payflow/common/utils/app_routes.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _navigate();
  }

  Future<void> _navigate() async {
    await Future.delayed(const Duration(seconds: 2));

    final authController = Get.find<AuthController>();

    if (authController.isAuthenticated.value) {
      if (authController.isUser) {
        Get.offAllNamed(AppRoutes.userHome);
      } else if (authController.isMerchant) {
        if (authController.isMerchantOnboarded.value) {
          Get.offAllNamed(AppRoutes.merchantHome);
        } else {
          Get.offAllNamed(AppRoutes.merchantOnboarding);
        }
      }
    } else {
      Get.offAllNamed(AppRoutes.roleSelection);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primary,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.account_balance_wallet_rounded,
              size: 200.sp,
              color: Colors.white,
            ),
            SizedBox(height: 32.h),
            Text(
              'PayFlow',
              style: TextStyle(
                fontSize: 84.sp,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
